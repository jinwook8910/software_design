package com.example.main_activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Hurry_menu extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hurry);
    }

}
