package com.example.main_activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btn1, btn2, btn3, btn4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = (Button) findViewById(R.id.button1);
        btn2 = (Button) findViewById(R.id.button2);
        btn3 = (Button) findViewById(R.id.button3);
        btn4 = (Button) findViewById(R.id.button4);

        btn1.setOnClickListener(listener);
        btn2.setOnClickListener(listener);
        btn3.setOnClickListener(listener);
        btn4.setOnClickListener(listener);

    }

    class Listener implements View.OnClickListener{
        public void onClick(View view){
            if(view==btn1){
                Intent intent = new Intent(MainActivity.this, Hurry_menu.class);
                startActivity(intent);
                //startActivityForResult();
            }
            else if(view==btn2){
                Intent intent =new Intent(MainActivity.this,Feel_menu.class);
                startActivity(intent);
            }
            else if(view==btn3){
                Intent intent = new Intent(MainActivity.this, Whatabout_menu.class);
                startActivity(intent);
            }
            else if(view==btn4) {
                // 종료
            }
        }
    }
    Listener listener = new Listener();



}